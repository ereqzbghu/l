//
//  AppDelegate.h
//  example-app
//
//  Created by Alexander Widerberg on 2017-02-03.
//  Copyright © 2017 example. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

